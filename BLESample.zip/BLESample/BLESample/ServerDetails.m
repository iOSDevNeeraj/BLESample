//
//  ServerDetails.m
//  BLEDemo
//
//  Created by Neeraj Shukla on 06/12/16.
//  Copyright © 2016 HannaInstruments. All rights reserved.
//

#import "ServerDetails.h"

@implementation ServerDetails
{
    BOOL inited;
    CBCentralManager *myCenter;
    //state
    NSInteger scanState;
    NSInteger connectState;
    NSInteger serviceState;
    NSInteger characteristicState;
    NSInteger readState;
    
    eventBlock connectBlock;
    
}

static ServerDetails* _defaultBTServer = nil;
-(NSInteger)getScanState
{
    return scanState;
}
-(NSInteger)getConnectState
{
    return connectState;
}
-(NSInteger)getServiceState
{
    return serviceState;
}
-(NSInteger)getCharacteristicState
{
    return characteristicState;
}
-(NSInteger)getReadState
{
    return readState;
}

+(ServerDetails *)defaultBTServer
{
    if (_defaultBTServer == nil)
    {
        _defaultBTServer = [[ServerDetails alloc] init];
        [_defaultBTServer initBLE];
    }
    return _defaultBTServer;
}

-(void)initBLE
{
    if (inited)
    {
        return;
    }
    inited = TRUE;
    self.delegate = nil;
    self.arrDiscoveredPeripherals = [NSMutableArray array];
    self.selectPeripheral = nil;
    connectState = K0;
    connectBlock = nil;
    
    NSDictionary *options = [NSDictionary dictionaryWithObjectsAndKeys:[NSNumber numberWithBool:YES],CBCentralManagerOptionShowPowerAlertKey,@"zStrapRestoreIdentifier",CBCentralManagerOptionRestoreIdentifierKey, nil];
    
    myCenter = [[CBCentralManager alloc] initWithDelegate:self queue:dispatch_queue_create("com.myBLEQueue", NULL) options:options];
    
    NSLog(@"Init BLE server");
}

-(void)startScan
{
    [self startScan:10];
}

-(void)startScan:(NSInteger)forLastTime
{
    [self.arrDiscoveredPeripherals removeAllObjects];
    
    scanState = K1;
    
#if 1
    NSArray *amtp = [NSArray arrayWithObjects:[CBUUID UUIDWithString:UUIDPrimaryService], [CBUUID UUIDWithString:UUIDPrimaryService2], nil];
    
    
    NSArray *arrRetrived = [myCenter retrieveConnectedPeripheralsWithServices:amtp];
    NSLog(@"Retrived array:\n %@", arrRetrived);
    
    for (CBPeripheral *peripheral in arrRetrived)
    {
        [self addPeripheral:peripheral advertisementData:nil  RSSI:nil];
    }
  
#endif
    [myCenter scanForPeripheralsWithServices:nil options:nil];
    
    if (forLastTime > 0)
    {
        [NSObject cancelPreviousPerformRequestsWithTarget:self selector:@selector(stopScan) object:nil];
        [self performSelector:@selector(stopScan) withObject:nil afterDelay:forLastTime];
    }
    
}

-(void)stopScan:(BOOL)withOutEvent
{
    if (scanState != K1)
    {
        return;
    }
    
    NSLog(@"stop scan ...");
    
    scanState = KSUCCESS;
    [myCenter stopScan];
    
    if(withOutEvent)
        return;
    
    if (self.delegate) {
        if([(id)self.delegate respondsToSelector:@selector(didStopScan)]){
            [self.delegate didStopScan];
        }
    }
}

-(void)stopScan
{
    [self stopScan:FALSE];
}

-(void)cancelConnect
{
    if (myCenter && self.selectPeripheral)
    {
        if(self.selectPeripheral.state == CBPeripheralStateConnecting)
        {
            
            NSLog(@"timeout cancel connect to peripheral:%@",self.selectPeripheral.name);
            
            [myCenter cancelPeripheralConnection:self.selectPeripheral];
            connectState = K0;
        }
    }
}

-(void)connect:(PeripheralInfo *)peripheralInfo
{
    NSLog(@"Connecting to peripheral: %@", peripheralInfo.peripheral.name);
    
    [myCenter connectPeripheral:peripheralInfo.peripheral options:@{CBConnectPeripheralOptionNotifyOnConnectionKey: @YES,CBConnectPeripheralOptionNotifyOnDisconnectionKey: @YES,CBConnectPeripheralOptionNotifyOnNotificationKey: @YES} ];
    
    self.selectPeripheral = peripheralInfo.peripheral;
    connectState = K1;
    [NSObject cancelPreviousPerformRequestsWithTarget:self
                                             selector:@selector(cancelConnect)
                                               object:nil];
    [self performSelector:@selector(stopScan) withObject:nil afterDelay:AUTO_CANCEL_CONNECT_TIMEOUT];
    
}

-(void)connect:(PeripheralInfo *)peripheralInfo withFinishCB:(eventBlock)callback
{
    [self connect:peripheralInfo];
    connectBlock = callback;
    
}

-(void)disConnect
{
    if (myCenter && self.selectPeripheral)
    {
        [myCenter cancelPeripheralConnection:self.selectPeripheral];
    }
}

-(void)discoverService:(CBService*)service
{
    if(self.selectPeripheral)
    {
        characteristicState = K1;
        self.discoveredService = service;
        [self.selectPeripheral discoverCharacteristics:nil forService:service];
    }
    
}

-(void)readValue:(CBCharacteristic *)characteristic
{
    if (readState == K1)
    {
        NSLog(@"BLE Server Details: Should wait read over");
        return;
    }
    if (characteristic != nil)
    {
        self.selectCharacteristic = characteristic;
    }
    readState = K1;
    [self.selectPeripheral readValueForCharacteristic:self.selectCharacteristic];
}

-(void)addPeripheral:(CBPeripheral*)peripheral advertisementData:(NSDictionary*)advertisementData RSSI:(NSNumber*)RSSI
{
    PeripheralInfo *pi = [[PeripheralInfo alloc]init];
    
    pi.peripheral = peripheral;
    pi.uuid = [peripheral.identifier UUIDString];
    pi.name = peripheral.name;
    
    switch (peripheral.state)
    {
        case CBPeripheralStateDisconnected:
            pi.state = @"disConnected";
            break;
        case CBPeripheralStateConnecting:
            pi.state = @"connecting";
            break;
        case CBPeripheralStateConnected:
            pi.state = @"connected";
            break;
        default:
            break;
    }
    
    if (advertisementData)
    {
        pi.localName = [advertisementData objectForKey:CBAdvertisementDataLocalNameKey];
        NSArray *array = [advertisementData objectForKey:CBAdvertisementDataServiceUUIDsKey];
        pi.serviceUUIDS = [array componentsJoinedByString:@"; "];
    }
    
    if (RSSI)
    {
        pi.RSSI = RSSI;
    }
    
    [self addPeripheralInfo:pi];
}

#pragma mark CBCentralManagerDelegate
-(void)addPeripheralInfo:(PeripheralInfo *)peripheralInfo
{
    for(int i=0;i<self.arrDiscoveredPeripherals.count;i++)
    {
        PeripheralInfo *pi = self.arrDiscoveredPeripherals[i];
        
        if([peripheralInfo.uuid isEqualToString:pi.uuid])
        {
            [self.arrDiscoveredPeripherals replaceObjectAtIndex:i withObject:peripheralInfo];
            return;
        }
    }
    
    [self.arrDiscoveredPeripherals addObject:peripheralInfo];
    
    if (self.delegate)
    {
        if([(id)self.delegate respondsToSelector:@selector(didFoundPeripheral)]){
            [self.delegate didFoundPeripheral];
        }
    }
}

-(void)centralManager:(CBCentralManager *)central didDiscoverPeripheral:(CBPeripheral *)peripheral advertisementData:(NSDictionary *)advertisementData RSSI:(NSNumber *)RSSI
{
    NSLog(@"Discovered peripheral: %@; advertisementData: %@; RSSI: %@", peripheral, advertisementData, RSSI);
    NSLog(@"Discover Peripheral: %@; RSSI: %@", peripheral.name, RSSI);
    [self addPeripheral:peripheral advertisementData:advertisementData RSSI:RSSI];
}

-(void)centralManager:(CBCentralManager *)central didConnectPeripheral:(CBPeripheral *)peripheral
{
    NSLog(@"Did Connect to peripheral: %@", peripheral.name);
    connectState = KSUCCESS;
    
    if (connectBlock)
    {
        connectBlock (peripheral,true,nil);
        connectBlock = nil;
    }
    self.selectPeripheral = peripheral;
    self.selectPeripheral.delegate = self;
    serviceState = K1;
    [self.selectPeripheral discoverServices:nil];
}

-(void)centralManager:(CBCentralManager *)central didDisconnectPeripheral:(CBPeripheral *)peripheral error:(NSError *)error
{
    NSLog(@"Did disconnect peripheral: %@", peripheral.name);
    
    connectState = KFAILED;
    
    if (connectBlock)
    {
        connectBlock (peripheral, false, nil);
        connectBlock = nil;
    }
    
    if (self.delegate)
    {
        if ([(id)_delegate respondsToSelector:@selector(didDisconnect)])
        {
            [self.delegate didDisconnect];
        }
    }
}

- (void)centralManager:(CBCentralManager *)central didFailToConnectPeripheral:(CBPeripheral *)peripheral error:(NSError *)error
{
    NSLog(@"DidFailToConnectPeripheral .....");
}

- (void)centralManager:(CBCentralManager *)central didRetrieveConnectedPeripherals:(NSArray *)peripherals
{
    NSLog(@"retrive connected peripheral %@",peripherals);
}

- (void)centralManager:(CBCentralManager *)central didRetrievePeripherals:(NSArray *)peripherals
{
    NSLog(@"retrive %@",peripherals);
    
}

- (void)centralManagerDidUpdateState:(CBCentralManager *)central
{
    // Determine the state of the peripheral
    if ([central state] == CBCentralManagerStatePoweredOff)
    {
        NSLog(@"CoreBluetooth BLE hardware is powered off");
    }
    else if ([central state] == CBCentralManagerStatePoweredOn)
    {
        NSLog(@"CoreBluetooth BLE hardware is powered on and ready");
    }
    else if ([central state] == CBCentralManagerStateUnauthorized)
    {
        NSLog(@"CoreBluetooth BLE state is unauthorized");
    }
    else if ([central state] == CBCentralManagerStateUnknown)
    {
        NSLog(@"CoreBluetooth BLE state is unknown");
    }
    else if ([central state] == CBCentralManagerStateUnsupported)
    {
        NSLog(@"CoreBluetooth BLE hardware is unsupported on this platform");
    }
    
}

- (void)centralManager:(CBCentralManager *)central willRestoreState:(NSDictionary *)dict
{
    NSLog(@"will restore ....");
}

#pragma mark CBPeripheralDelegate
- (void)peripheral:(CBPeripheral *)peripheral didDiscoverServices:(NSError *)error
{
    if (nil == error)
    {
        serviceState = KSUCCESS;
        //        NSLog(@"found services:\n%@",peripheral.services);
    }
    else
    {
        serviceState = KFAILED;
        NSLog(@"discover service failed:%@",error);
    }
}

- (void)peripheral:(CBPeripheral *)peripheral didDiscoverCharacteristicsForService:(CBService *)service error:(NSError *)error
{
    if (nil == error)
    {
        characteristicState = KSUCCESS;
        self.discoveredService = service;
    }
    else
    {
        characteristicState = KFAILED;
        self.discoveredService = nil;
        NSLog(@"discover characteristic failed:%@",error);
    }
    
}

- (void)peripheral:(CBPeripheral *)peripheral didUpdateValueForCharacteristic:(CBCharacteristic *)characteristic error:(NSError *)error
{
    if (error)
    {
        readState = KFAILED;
        NSLog(@"Error updating value for characteristic %@ error: %@", characteristic.UUID, [error localizedDescription]);
        return;
    }
    
    readState = KSUCCESS;
    self.selectCharacteristic = characteristic;
    if (self.delegate && [(id)self.delegate respondsToSelector:@selector(didReadvalue)])
        [self.delegate didReadvalue];
}



@end
