//
//  ShowPeripheralVC.h
//  BLESample
//
//  Created by Neeraj Shukla on 08/12/16.
//  Copyright © 2016 HannaInstruments. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ServerDetails.h"
#import "ProgressHUD.h"

@interface ShowPeripheralVC : UIViewController <UITableViewDelegate,UITableViewDataSource, ServerDetailsDelegate>

@property (strong, nonatomic) ServerDetails *defaultBLEServer;
@property (weak, nonatomic) IBOutlet UILabel *lblName;

@end
