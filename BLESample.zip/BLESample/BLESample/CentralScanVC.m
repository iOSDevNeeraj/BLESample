//
//  FirstViewController.m
//  BLEDemo
//
//  Created by Neeraj Shukla on 06/12/16.
//  Copyright © 2016 HannaInstruments. All rights reserved.
//

#import "CentralScanVC.h"
#import "myTableViewCell.h"
#import "ServerDetails.h"
#import "PeripheralInfo.h"
#import "ProgressHUD.h"

@interface CentralScanVC ()

@end

@implementation CentralScanVC

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
    self.defaultBLEServer = [ServerDetails defaultBTServer];
    self.defaultBLEServer.delegate = (id)self;
    [self.defaultBLEServer startScan];
    [ProgressHUD dismiss];
    
    self.tf_scanInfo.text = @"Scanning ...";
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - BLE Server Delegate
-(void)didStopScan
{
    dispatch_async(dispatch_get_main_queue(), ^{
        self.tf_scanInfo.text = @"Scan Stopped";
    });
}

-(void)didFoundPeripheral
{
    dispatch_async(dispatch_get_main_queue(), ^{
        [_tblView_CentralView reloadData];
    });
}

-(void)didDisconnect
{
    [ProgressHUD show:@"Disconnect from peripheral"];
}

- (IBAction)reFresh:(id)sender
{
    [[UIApplication sharedApplication] sendAction:@selector(resignFirstResponder) to:nil from:nil forEvent:nil];
    
    [self.defaultBLEServer stopScan:TRUE];
    
    self.tf_scanInfo.text = @"Scanning ...";
    self.defaultBLEServer.delegate = (id)self;
    [self.defaultBLEServer startScan];
    [self.tblView_CentralView reloadData];
    
}

#pragma mark - Table View Delegate
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    int rows = [self.defaultBLEServer.arrDiscoveredPeripherals count];
    return rows;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [self.defaultBLEServer stopScan:YES];
    [ProgressHUD show:@"Connecting"];
    
    [self.defaultBLEServer connect:self.defaultBLEServer.arrDiscoveredPeripherals[indexPath.row] withFinishCB:^(CBPeripheral *peripheral, BOOL status, NSError *error){
        dispatch_async(dispatch_get_main_queue(), ^{
            
            [ProgressHUD dismiss];
            
            if (status)
            {
                [ProgressHUD show:@"Connected successfully!"];
                [self performSegueWithIdentifier:@"getService" sender:nil];
            }
            else
            {
                [ProgressHUD show:@"Connection failed!"];
            }
        });
    }];
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *identifier = @"PeripheralCell";
    MyTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
    
    if (cell == nil)
    {
        cell = [[MyTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:identifier];
    }
    
    cell.backgroundColor = [UIColor lightGrayColor];
    
    PeripheralInfo *pi = self.defaultBLEServer.arrDiscoveredPeripherals[indexPath.row];
    
    cell.topName.text = pi.name;
    cell.uuid.text = pi.uuid;
    cell.name.text = pi.localName;
    cell.service.text = pi.serviceUUIDS;
    cell.RSSI.text = [pi.RSSI stringValue];
    cell.RSSI.textColor = [UIColor blackColor];
    
    int rssiValue = [pi.RSSI intValue];
    
    //Putting the alarms:
    if (rssiValue > -60)
    {
        cell.RSSI.textColor = [UIColor redColor];
    }
    else if (rssiValue > -70)
    {
        cell.RSSI.textColor = [UIColor orangeColor];
    }
    else if (rssiValue > -80)
    {
        cell.RSSI.textColor = [UIColor blueColor];
    }
    else if (rssiValue > -90)
    {
        cell.RSSI.textColor = [UIColor blackColor];
    }
    
    return cell;
}

-(void)KeyboardDisappear:(BOOL)isUP
{
    NSTimeInterval animationDuration = 0.30f;
    [UIView beginAnimations:@"ResizeForKeyBoard" context:nil];
    [UIView setAnimationDuration:animationDuration];
    float width = self.view.frame.size.width;
    float height = self.view.frame.size.height;
    CGRect rect;
    
    if(isUP)
    {
        rect = CGRectMake(0.0f, -216,width,height);
    }
    else
    {
        rect = CGRectMake(0.0f, 0,width,height);
        
    }
    self.view.frame = rect;
    [UIView commitAnimations];
}

-(void)scrollViewWillBeginDragging:(UIScrollView *)scrollView {
    [[UIApplication sharedApplication] sendAction:@selector(resignFirstResponder) to:nil from:nil forEvent:nil];
}

@end
