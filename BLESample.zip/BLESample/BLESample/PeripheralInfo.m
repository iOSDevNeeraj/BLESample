//
//  PeripheralInfo.m
//  BLEDemo
//
//  Created by Neeraj Shukla on 06/12/16.
//  Copyright © 2016 HannaInstruments. All rights reserved.
//

#import "PeripheralInfo.h"

@implementation PeripheralInfo

@end
