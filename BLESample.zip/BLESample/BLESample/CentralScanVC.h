//
//  FirstViewController.h
//  BLEDemo
//
//  Created by Neeraj Shukla on 06/12/16.
//  Copyright © 2016 HannaInstruments. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ServerDetails.h"


@interface CentralScanVC : UIViewController <UITableViewDelegate, UITableViewDataSource, ServerDetailsDelegate, UITextFieldDelegate>

@property (strong, nonatomic)ServerDetails *defaultBLEServer;

@property (weak, nonatomic) IBOutlet UITextField *tf_scanInfo;
@property (weak, nonatomic) IBOutlet UITableView *tblView_CentralView;


@end

