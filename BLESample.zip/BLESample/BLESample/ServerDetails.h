//
//  ServerDetails.h
//  BLEDemo
//
//  Created by Neeraj Shukla on 06/12/16.
//  Copyright © 2016 HannaInstruments. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreBluetooth/CoreBluetooth.h>
#import "PeripheralInfo.h"

#define UUIDPrimaryService  @"0xFF00"//tmp 0XFFA0 should be 0xFF00
#define UUIDPrimaryService2  @"0xFFA0"//tmp 0XFFA0 should be 0xFF00
#define UUIDDeviceInfo      @"0xFF01"
#define UUIDRealTimeDate    @"0xFF02"
#define UUIDControlPoint    @"0xFF03"
#define UUIDData            @"0xFF04"
#define UUIDFirmwareData    @"0xFF05"
#define UUIDDebugData       @"0xFF06"

#define UUIDBLEUserInfo     @"0xFF07"

#define AUTO_CANCEL_CONNECT_TIMEOUT 10

typedef void (^eventBlock)(CBPeripheral *peripheral, BOOL status, NSError *error);
typedef enum{
    K0 = 0,
    K1 = 1,
    KSUCCESS = 2,
    KFAILED = 3,
}myStatus;

@protocol ServerDetailsDelegate
@optional
-(void)didStopScan;
-(void)didFoundPeripheral;
-(void)didReadvalue;

@required
-(void)didDisconnect;

@end


@interface ServerDetails : NSObject<CBCentralManagerDelegate, CBPeripheralDelegate>
+(ServerDetails*)defaultBTServer;
@property (weak, nonatomic) id <ServerDetailsDelegate> delegate;

@property (strong,nonatomic) NSMutableArray *arrDiscoveredPeripherals;
@property (strong,nonatomic) CBPeripheral *selectPeripheral;
@property (strong,nonatomic) CBService *discoveredService;
@property (strong,nonatomic) CBCharacteristic *selectCharacteristic;

-(void)startScan;
-(void)startScan:(NSInteger)forLastTime;
-(void)stopScan;
-(void)stopScan:(BOOL)withOutEvent;
-(void)connect:(PeripheralInfo *)peripheralInfo withFinishCB:(eventBlock)callback;
-(void)disConnect;
-(void)discoverService:(CBService*)service;
-(void)readValue:(CBCharacteristic*)characteristic;

//state
-(NSInteger)getConnectState;
-(NSInteger)getServiceState;
-(NSInteger)getCharacteristicState;

@end
