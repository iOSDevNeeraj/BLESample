//
//  ShowPeripheralVC.m
//  BLESample
//
//  Created by Neeraj Shukla on 08/12/16.
//  Copyright © 2016 HannaInstruments. All rights reserved.
//

#import "ShowPeripheralVC.h"

@interface ShowPeripheralVC ()

@end

@implementation ShowPeripheralVC

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    self.defaultBLEServer = [ServerDetails defaultBTServer];
    self.defaultBLEServer.delegate = (id) self;
    self.lblName.text = self.defaultBLEServer.selectPeripheral.name;
    
}

-(void)viewDidAppear:(BOOL)animated
{
    self.defaultBLEServer.delegate = self;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)didDisconnect
{
    dispatch_async(dispatch_get_main_queue(), ^{
        [ProgressHUD showSuccess:@"Disconnected from peripheral!"];
        [self.navigationController popToRootViewControllerAnimated:YES];
    });
}

- (IBAction)goBack:(id)sender
{
    [self.defaultBLEServer disConnect];
}

#pragma mark - Table View Delegate
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
    
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if ([self.defaultBLEServer getServiceState] == K1)
    {
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            
            [tableView reloadData];
        });
        return 0;
    }
    else if ([self.defaultBLEServer getServiceState] == KFAILED)
    {
        return 0;
    }
    
    int rows = [self.defaultBLEServer.selectPeripheral.services count];
    return rows;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    CBService *service = self.defaultBLEServer.selectPeripheral.services[indexPath.row];
    
    [self.defaultBLEServer discoverService:service];
    
   // [self performSegueWithIdentifier:@"getCharacteristic" sender:self];
    
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *identifier = @"ServiceCell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
    
    if (cell == nil)
    {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:identifier];
    }
    cell.backgroundColor = [UIColor blueColor];

    CBService *service = self.defaultBLEServer.selectPeripheral.services[indexPath.row];
    cell.textLabel.text = [service.UUID UUIDString];
    cell.detailTextLabel.text = [NSString stringWithFormat:@"UUID: %@", [service.UUID UUIDString]];
    
    return cell;
}

@end
